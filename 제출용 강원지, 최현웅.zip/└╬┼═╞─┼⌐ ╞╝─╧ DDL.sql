create sequence member_seq
    start with 1
    maxvalue 99999
    increment by 1
    nocycle
    nocache;
    
create sequence works_seq
    start with 1
    maxvalue 99999
    increment by 1
    nocycle
    nocache;
    
create table member(
    id                  number		    default member_seq.nextval primary key,
    userid          varchar2(100) 	unique not null,
    userpw	        varchar2(500)	not null,
    username   varchar2(100)   not null,
    email           varchar2(100)   not null,
    gender        	varchar2(100)   check(gender in ('��', '��')),
    pNum          varchar2(100)	default 0 not null,
    isAdmin		number		    default 0 check(isAdmin in (0, 1)),
    deleted		number		    default 0 check(deleted in (0, 1)),
    age             number             default 0
);

create table works(
    id                  number		            default works_seq.nextval primary key,
    title               varchar2(2000)	        not null,
    writer              varchar2(100)       not null,
    content          	varchar2(4000)      not null,
    uploadDate   	date		                default sysdate,
    showDate		    date		                default sysdate,
    genre		        varchar2(300)	    not null,
    viewCount		number		        default 0,
    ageLimit		    number		        not null,
    price		        number		        not null,
    deleted		    number		        default 0 check(deleted in (0, 1)),
    area		            varchar2(500)	    not null,
    image		        varchar2(4000)	    not null,

    constraint works_member_fk
    foreign key (writer)
    references member(userid)
);


create table reply (
    id                  number             generated as identity primary key,
    works_id    number             not null,
    writer          varchar2(100)      not null,
    content        varchar2(2000)     not null,
    writedate	   date               default sysdate,
    lev               number             default 0,
    ref               number             default 0,
    isReview	    number	      default 0,
    
    constraint reply_works_fk
    foreign key (works_id)
    references works(id),
    
    constraint reply_member_fk
    foreign key (writer)
    references member(userid)
);

create table likey(
    id                         number             generated as identity primary key,
    member_userid  varchar2(100)    not null,
    works_id	            number              not null,

    constraint likey_works_fk
    foreign key (works_id)
    references works(id),
    
    constraint likey_member_fk
    foreign key (member_userid)
    references member(userid)
);

create table booking(
    id                          number           generated as identity primary key,
    bookDate            date		             default sysdate,
    works_id            number	             not null,
    member_userid  varchar2(100)    not null,
    seatNum	            number             not null,
    deleted	            number             default 0 check(deleted in (0, 1)),

    constraint booking_member_fk
    foreign key (member_userid)
    references member(userid),
    
    constraint booking_works_fk
    foreign key (works_id)
    references works(id)
);
