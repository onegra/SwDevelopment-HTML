package ex04;

public class Test1 {

	// 외부에서 호출 가능한 생성자
	public Test1() {
		System.out.println("Test1 생성자 호출 !!");
	}
}
